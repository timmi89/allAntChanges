=== ReadrBoard ===
Contributors: ReadrBoard
Tags: reactions, comments, sharing, social, engagement

ReadrBoard lets your readers express their reaction to any phrase, picture, video, or article on your website -- with the ease of a 'like' button.

== Description ==

When readers select text or hover over an image or video, they are shown a small widget that lets them express any reaction with the ease of a 'like' button.  All of your readers can then easily see the aggregated reactions of your community through our summary widget.  Everything works right out-of-the-box, but it's also customizable.

== Installation ==

Just activate the plugin and follow the instructions on the ReadrBoard Settings page found  in the plugins menu.

1, 2, 3 and you're done!

== Changelog ==

= 0.0.1 =
First Beta Version Released